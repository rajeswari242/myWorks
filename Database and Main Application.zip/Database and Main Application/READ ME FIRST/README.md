# AWS-Powered Image Classification

## Requirements
- Flask
- Flask-SQLAlchemy

## Setup

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Set up the database:
   ```bash
   from app import db
   db.create_all()
